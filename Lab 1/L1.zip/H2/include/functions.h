#ifndef INCLUDE_FUNCTIONS_H_
#define INCLUDE_FUNCTIONS_H_

#include <stdint.h>

void FillArray(int *arr, int size);
int64_t SumArray(int *arr, int size);

#endif  // INCLUDE_FUNCTIONS_H_
