#ifndef INCLUDE_FUNCTIONS_H_
#define INCLUDE_FUNCTIONS_H_

void TellJoke(int);
void GivePunchline(int);

#endif  // INCLUDE_FUNCTIONS_H_
